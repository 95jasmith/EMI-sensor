#ifndef _DEFINES_H
#define _DEFINES_H

const auto ERROR_OK = 0;
//const int ERROR_NOT_READY = 21;
//constexpr auto ERROR_ERROR = 100;
//constexpr auto ERROR_ALREADY_INITIALIZED = 123;
//constexpr auto ERROR_NOT_ENOUGH_MEMORY = 124;
constexpr auto ERROR_NOT_CREATED = 125;
constexpr auto ERROR_WAIT_ERROR = 126;
constexpr auto ERROR_WAIT_BUSY = 127;


#endif